package com.hawking.controller;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zoho.hawking.HawkingTimeParser;
import com.zoho.hawking.datetimeparser.configuration.HawkingConfiguration;
import com.hawking.model.Configuration;
import com.hawking.model.InputDTO;
import com.hawking.model.OutputDTO;
import com.hawking.model.User;
import com.zoho.hawking.language.english.model.DatesFound;
import com.hawking.repository.ConfigRepository;
import com.hawking.repository.ConfigurationHandler;
import com.hawking.repository.UserRegistration;
import com.hawking.repository.UserRepository;
@CrossOrigin(origins="http://localhost:3000")
@RestController
public class MainController {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ConfigRepository configRepository;
	
	@GetMapping("/healthCheck")
	public String get() {
		return "Success";
	}
	
	@PostMapping("/demoStringParser")
	public OutputDTO demoStringParser(@RequestBody InputDTO input) throws Exception {
		
		OutputDTO response = new OutputDTO();
		
		HawkingConfiguration hawkingConfiguration = new HawkingConfiguration();
		hawkingConfiguration.setFiscalYearStart(2);
	    hawkingConfiguration.setFiscalYearEnd(1);
	    hawkingConfiguration.setTimeZone("IST");
	    Date referenceDate = new Date();
		HawkingTimeParser parser = new HawkingTimeParser();
		DatesFound datesFound = parser.parse(input.getText(), referenceDate,hawkingConfiguration, "eng");
		
		response.setResponse(datesFound.toString());
		
		return response;
	}
	
	@PostMapping("/userRegister")
	public Object userRegister(@RequestBody User input) throws Exception {
		OutputDTO response = new OutputDTO();
		try {
			UserRegistration userReg = UserRegistration.getInstance(userRepository);
			if(userReg.getUser(input.getEmail()) != null) {
				response.setResponse("Email ID already exist, Please user another email ID.");
			}
			else {
				userReg.addUser(input);
				response.setUser(input);
				response.setResponse("Success");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			response.setResponse("Exception occured");
		}
		return response;
	}
	
	@PostMapping("/userLogin")
	public OutputDTO userLogin(@RequestBody User input) throws Exception {
		OutputDTO response = new OutputDTO();
		try {
			UserRegistration userReg = UserRegistration.getInstance(userRepository);
			User user = userReg.getUser(input.getEmail());
			if(user.getPassword().equals(input.getPassword())) {
				user.setToken(UUID.randomUUID());
				userReg.addUser(user);
				response.setUser(user);
				response.setResponse("Login Success");
			} else {
				response.setResponse("Login failed");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			response.setResponse("Exception occured");
		}
		return response;
	}
	
	@PostMapping("/userLogout")
	public OutputDTO userLogout(@RequestBody User input) {
		OutputDTO response = new OutputDTO();
		try {
			UserRegistration userReg = UserRegistration.getInstance(userRepository);
			User user = userReg.getUser(input.getEmail());
			if(user.getToken().toString().equals(input.getToken().toString())) {
				user.setToken(null);
				userReg.addUser(user);
				response.setResponse("Logout Success");
			} else {
				response.setResponse("Logout failed");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			response.setResponse("Exception occured");
		}
		return response;
	}
	
	@PostMapping("/updateConfigs")
	public OutputDTO updateConfigs(@RequestBody InputDTO input) {
		OutputDTO response = new OutputDTO();
		try {
			UserRegistration userReg = UserRegistration.getInstance(userRepository);
			ConfigurationHandler configHandler = ConfigurationHandler.getInstance(configRepository);
			User user = userReg.getUser(input.getEmail());
			if(user.getToken().toString().equals(input.getToken())) {
				Configuration configs = input.getConfigs();
				if(configs == null) {
					response.setResponse("No configuration have been provided");
				} else {
					configs.setEmail(input.getEmail());
					configHandler.udpateConfigs(configs);
					response.setConfigs(configs);
					response.setResponse("Configuration have been updated");
				}
			} else {
				response.setResponse("Authentication failed");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			response.setResponse("Exception occured");
		}
		return response;
	}
	
	@PostMapping("/parseString")
	public OutputDTO parseString(@RequestBody InputDTO input) {
		OutputDTO response = new OutputDTO();
		try {
			UserRegistration userReg = UserRegistration.getInstance(userRepository);
			ConfigurationHandler configHandler = ConfigurationHandler.getInstance(configRepository);
			
			User user = userReg.getUser(input.getEmail());
			
			if(user.getToken().toString().equals(input.getToken())) {
				
				Configuration configs = configHandler.getConfigs(input.getEmail());
				HawkingConfiguration hawkingConfiguration = mapConfiguration(configs);
				Date referenceDate = new Date();
				HawkingTimeParser parser = new HawkingTimeParser();
				DatesFound datesFound = parser.parse(input.getText(), referenceDate, hawkingConfiguration, "eng");
				
				response.setResponse(datesFound.toString());
			} else {
				response.setResponse("Authentication failed");
			}
		} catch(Exception ex) {
			ex.printStackTrace();
			response.setResponse("Exception occured");
		}
		return response;
	}
	
	private HawkingConfiguration mapConfiguration(Configuration configs) throws Exception {
		HawkingConfiguration hawkingConfiguration = new HawkingConfiguration();
		hawkingConfiguration.setTimeZone(configs.getTimeZone());
		hawkingConfiguration.setDateFormat(configs.getDateFormat());
		hawkingConfiguration.setFiscalYearEnd(configs.getFiscalYearEnd());
		hawkingConfiguration.setFiscalYearStart(configs.getFiscalYearStart());
		return hawkingConfiguration;
	}
	
}
