package com.hawking.repository;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.hawking.model.Configuration;
@CrossOrigin(origins={"http://localhost:3000"})
@Component
public class ConfigurationHandler {
	
	private static ConfigurationHandler configurationHandler = null;
	
	private static ConfigRepository configRepository;
	
	private ConfigurationHandler() {
		
	}
	
	public static ConfigurationHandler getInstance(ConfigRepository configRepo) {
		if(configurationHandler == null) {
			configRepository = configRepo;
			configurationHandler = new ConfigurationHandler();
		}
		return configurationHandler;
	}
	
	public void udpateConfigs(Configuration configs) {
		configRepository.save(configs);
	}
	
	public Configuration getConfigs(String email) {
		return configRepository.findById(email).orElse(null);
	}
}

