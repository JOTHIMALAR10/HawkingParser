package com.hawking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hawking.model.Configuration;

public interface ConfigRepository  extends JpaRepository<Configuration,String>  {

}
