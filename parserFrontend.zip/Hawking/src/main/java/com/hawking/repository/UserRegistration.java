package com.hawking.repository;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.hawking.model.User;
@CrossOrigin(origins={"http://localhost:3000"})
@Component
public class UserRegistration {
	
	private static UserRegistration userRegistration = null;
	
	private static UserRepository userRepository;
	
	private UserRegistration() {
		
	}
	
	public static UserRegistration getInstance(UserRepository userRepo) {
		if(userRegistration == null) {
			userRepository = userRepo;
			userRegistration = new UserRegistration();
		}
		return userRegistration;
	}
	
	public void addUser(User user) {
		userRepository.save(user);
	}
	
	public User getUser(String email) {
		return userRepository.findById(email).orElse(null);
	}
	
}

