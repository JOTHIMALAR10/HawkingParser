package com.hawking.model;

public class InputDTO {

	private String text;
	private String email;
	private String token;
	private Configuration configs;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Configuration getConfigs() {
		return configs;
	}

	public void setConfigs(Configuration configs) {
		this.configs = configs;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
}

