package com.hawking.model;

public class OutputDTO {
	private String response;
	private User user;
	private Configuration configs;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Configuration getConfigs() {
		return configs;
	}

	public void setConfigs(Configuration configs) {
		this.configs = configs;
	}
	

}
