package com.hawking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.web.bind.annotation.CrossOrigin;
@CrossOrigin(origins={"http://localhost:3000"})
@Entity
public class Configuration {
	
	@Id
	private String email;
	
	@Column
	private String timeZone;
	
	@Column
	private String dateFormat;
	
	@Column
	private int fiscalYearStart;
	
	@Column
	private int fiscalYearEnd;
	
	public Configuration() {
		
	}
	
	public Configuration(String email, String timeZone, String dateFormat, int fiscalYearStart, int fiscalYearEnd) {
		super();
		this.email = email;
		this.timeZone = timeZone;
		this.dateFormat = dateFormat;
		this.fiscalYearEnd = fiscalYearEnd;
		this.fiscalYearStart = fiscalYearStart;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public int getFiscalYearStart() {
		return fiscalYearStart;
	}

	public void setFiscalYearStart(int fiscalYearStart) {
		this.fiscalYearStart = fiscalYearStart;
	}

	public int getFiscalYearEnd() {
		return fiscalYearEnd;
	}

	public void setFiscalYearEnd(int fiscalYearEnd) {
		this.fiscalYearEnd = fiscalYearEnd;
	}

	@Override
	public String toString() {
		return "Configuration [email=" + email + ", timeZone=" + timeZone + ", dateFormat=" + dateFormat
				+ ", fiscalYearStart=" + fiscalYearStart + ", fiscalYearEnd=" + fiscalYearEnd + "]";
	}
	
}

