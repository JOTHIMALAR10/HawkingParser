package com.hawking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HawkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HawkingApplication.class, args);
	}

}
