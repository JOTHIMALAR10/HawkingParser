package com.hawking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HawkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
